# ghost-copier
Factorio mod that copies attributes from a ghost when placed manually.
